# KaamKhoj - Job Marketplace App

A fully responsive, mobile-first job marketplace application built with HTML, Tailwind CSS, and vanilla JavaScript.

## Features

### 🎯 Core Features
- **Mobile-First Design**: Native app-like UI optimized for mobile devices
- **Multi-Role Support**: Both Job Seekers and Job Posters can use the app
- **Fixed Header**: KaamKhoj branding with hamburger menu
- **Bottom Navigation**: Home, Post, Inbox, Profile tabs
- **Sidebar Menu**: Quick access to My Posts, Saved, Settings, Logout

### 📱 User Interface
- **Modern Design**: Calming gradients and soft shadows
- **Responsive Layout**: Works on all mobile screen sizes
- **Touch-Optimized**: Disabled zoom, right-click, and text selection
- **Smooth Animations**: Slide-in sidebar and fade transitions

### 💼 Job Features
- **Job Categories**: Tech, Design, Sales, Food, Education
- **Location-Based**: Auto-detect and filter by location
- **Job Cards**: Company profile, salary, location, tags
- **Search & Filter**: Find jobs by keywords and categories
- **Save Jobs**: Heart icon to save favorite jobs

### ✍️ Post Jobs
- **Simple Form**: Title, category, salary, location, contact
- **Post Types**: 
  - Text Post (Free)
  - Image Post (₹50)
  - Video Post (₹100)
- **Success Modal**: Confirmation after posting

### 💬 Communication
- **Inbox**: Message list with companies
- **Chat Interface**: Mock conversation view
- **Notifications**: Unread message indicators

### 👤 Profile Management
- **User Profile**: Avatar, stats, location
- **Resume Upload**: PDF or video resume support
- **Settings**: Edit profile, notifications, privacy

## Technical Details

### Built With
- **HTML5**: Semantic structure
- **Tailwind CSS**: Utility-first styling
- **Vanilla JavaScript**: No external dependencies
- **Font Awesome**: Icons
- **Single File**: Complete app in one HTML file

### Mobile Optimizations
- Viewport meta tag with user-scalable=no
- Touch-action CSS for gesture control
- Disabled context menu and zoom gestures
- Mobile-first responsive design
- Fixed header and bottom navigation

### Browser Support
- Modern mobile browsers (Chrome, Safari, Firefox)
- iOS Safari and Android Chrome optimized
- Progressive Web App ready

## Installation & Usage

1. **Download**: Extract the ZIP file
2. **Open**: Double-click `kaamkhoj.html` or open in any web browser
3. **Mobile Testing**: Use browser dev tools to simulate mobile devices
4. **PWA Conversion**: Can be easily converted to a Progressive Web App

## File Structure
```
kaamkhoj-app/
├── kaamkhoj.html     # Complete application
├── README.md         # This file
└── screenshots/      # App screenshots (if included)
```

## Features Implemented

✅ Fixed top header with menu  
✅ Bottom navigation bar  
✅ Sidebar menu with overlay  
✅ Job cards with company profiles  
✅ Post job form with pricing tiers  
✅ Inbox with message list  
✅ User profile with stats  
✅ Mobile-optimized interactions  
✅ Gradient backgrounds and modern UI  
✅ Form validation and success modal  
✅ Heart/save functionality  
✅ Location-based filtering  
✅ Category-based job browsing  

## Future Enhancements

- Real backend integration
- User authentication
- Real-time messaging
- Push notifications
- Geolocation services
- Payment integration
- Resume parsing
- Job matching algorithm

## License

This project is created for demonstration purposes. Feel free to modify and use as needed.

---

**KaamKhoj** - Find your perfect job opportunity! 🚀

